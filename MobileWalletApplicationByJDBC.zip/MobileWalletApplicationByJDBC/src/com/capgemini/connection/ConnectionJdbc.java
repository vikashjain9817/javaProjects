package com.capgemini.connection;


import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionJdbc {
	
	public static Connection getConnection() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","Vik0980ash");  
			return con;
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
		return null;
	}
}
