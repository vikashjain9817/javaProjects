package com.cg.mra.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.exception.AccountIdNotFoundException;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class MainTesting {

	private static AccountDao accountdao = new AccountDaoImpl();
	private static AccountService accountService = new AccountServiceImpl(accountdao);
	/*
	 * When the mobile number is valid 
	 * then show balance successfully.
	 */
	@Test
	public void WhenTheMobileNumberIsValidThenShowBalanceSuccessfully() throws AccountIdNotFoundException {
		
		assertEquals(521, accountService.getAccountDetails("7599962922").getAccountBalance(), 0.01);
	}
	/*
	 * Mobile number not exists for showing balance.
	 */
	@Test(expected = AccountIdNotFoundException.class)
     public void WhenTheMobileNumberIsInValidToShowbalanceThenThrowAnException() throws AccountIdNotFoundException{
		
		accountService.getAccountDetails("9897421625");
	}
	/*
	 * Mobile number not exists for recharge balance.
	 */
	@Test(expected = AccountIdNotFoundException.class)
    public void WhenTheMobileNumberIsInValidToRechargeThenThrowAnException() throws AccountIdNotFoundException {
		
		accountService.rechargeAccount("9897421625", 200);
	}
	
	/*
	 * When Mobile number is exists for recharge balance.
	 * Then Mobile recharge successfullt.
	 */
	@Test
    public void WhenTheMobileNumberIsValidToRechargeThenRechargeSuccessfully() throws AccountIdNotFoundException {
		
		accountService.rechargeAccount("8171575996", 200);
		assertEquals(832, accountService.getAccountDetails("8171575996").getAccountBalance(), 0.01);
	}

}
