package com.cg.mra.service;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.AccountIdNotFoundException;

public interface AccountService {
	
	public Account getAccountDetails(String mobileNumber) throws AccountIdNotFoundException;
	public double rechargeAccount(String mobileNumber,double rechargeAmount) throws AccountIdNotFoundException;
}
