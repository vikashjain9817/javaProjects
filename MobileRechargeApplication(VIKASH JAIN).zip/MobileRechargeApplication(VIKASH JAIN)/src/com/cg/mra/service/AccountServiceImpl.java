package com.cg.mra.service;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDao;
import com.cg.mra.exception.AccountIdNotFoundException;

public class AccountServiceImpl implements AccountService {

	/*
	 * Reference of dao class.
	 */
	AccountDao accountdao;
	/*
	 * constructor which takes the object of dao class 
	 * as reference.
	 */
	public AccountServiceImpl(AccountDao accountdao) {
		super();
		this.accountdao = accountdao;
	}
	/*
	 * This Method will return the object of account class
	 * of given mobile number.
	 */
	@Override
	public Account getAccountDetails(String mobileNumber) throws AccountIdNotFoundException {
		Account account = accountdao.getAccountDetails(mobileNumber);
		if(account==null) {
			throw new AccountIdNotFoundException("Given account is not exist");
		}
		return account;
	}
	/*
	 * This Method will recharge the account of given mobile number.
	 */
	@Override
	public double rechargeAccount(String mobileNumber, double rechargeAmount) throws AccountIdNotFoundException {
		Account account = accountdao.getAccountDetails(mobileNumber);
		if(account!=null) {
			return accountdao.rechargeAccount(mobileNumber, rechargeAmount);
		}
		throw new AccountIdNotFoundException("Cannot recharge account as given mpbile number does not exist");
	}

}
