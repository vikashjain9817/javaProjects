package com.cg.mra.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.mra.beans.Account;

public class AccountDaoImpl implements AccountDao {
	/*
	 * Reference of Map collection.
	 */
	Map<String,Account> accountEntry;
	
	/*
	 * Constructor Which will intilize the map
	 * with given default values.
	 */
	public AccountDaoImpl() {
		super();
		accountEntry = new HashMap<>();
		accountEntry.put("9010210131", new Account("Prepaid", "vaishali", 200));
		accountEntry.put("9823920123", new Account("Prepaid", "Megha", 453));
		accountEntry.put("9932012345", new Account("Prepaid", "vikas", 631));
		accountEntry.put("7599962922", new Account("Prepaid", "Anju", 521));   // due to same key given(in first entry), I changed the key.
		accountEntry.put("8171575996", new Account("Prepaid", "Tushar", 632)); // due to same key given(in first entry), I changed the key.
	}
	/*
	 * This Method will return The Object of account class
	 */
	@Override
	public Account getAccountDetails(String mobileNumber) {
		Account account = null;
		for(Map.Entry<String, Account> entry : accountEntry.entrySet()) {
			if(entry.getKey().equals(mobileNumber)) {
				account = entry.getValue();
			}
		}
		return account;
	}
	/*
	 * This Method will return The amount of account class.
	 */
	@Override
	public double rechargeAccount(String mobileNumber, double rechargeAmount) {
		accountEntry.get(mobileNumber).setAccountBalance(accountEntry.get(mobileNumber).getAccountBalance()+rechargeAmount);
		return 1;
	}

}
