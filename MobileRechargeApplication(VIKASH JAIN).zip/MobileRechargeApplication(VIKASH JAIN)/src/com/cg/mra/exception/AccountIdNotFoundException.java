package com.cg.mra.exception;

public class AccountIdNotFoundException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AccountIdNotFoundException(String msg) {
		super(msg);
	}
}
