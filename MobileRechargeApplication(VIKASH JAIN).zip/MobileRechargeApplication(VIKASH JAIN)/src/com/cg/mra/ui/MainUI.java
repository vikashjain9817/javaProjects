package com.cg.mra.ui;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class MainUI {
	/*
	 * objects of scanner, dao and Service class.
	 */
	private static Scanner sc = new Scanner(System.in);
	private static AccountDao accountdao = new AccountDaoImpl();
	private static AccountService accountService = new AccountServiceImpl(accountdao);

	public static void main(String[] args) {
		showMenu();
	}
	/*
	 * This is for show menu.
	 */
	private static void showMenu() {
		int choice;
		while (true) {
			System.out.println("1.Account balance enquiry");
			System.out.println("2.Recharge Account");
			System.out.println("3.Exit");
			choice = sc.nextInt();
			switch (choice) {
			case 1: accountBalanceEnq();break;
			case 2: rechargeAccount();break;
			case 3: System.exit(0);
			default:System.out.println("Wrong choice!!!");break;
			}
		}

	}

	/*
	 * This method will return the amount.
	 */
	private static void accountBalanceEnq() {
		System.out.println("__________________________________________________________________________________");
		System.out.println("Enter mobile number");
		sc.nextLine();
		String mobileNo = sc.nextLine();
		while(!validateMobileNo(mobileNo)) {
			System.out.println("Invalid Mobile number :: Try Again!!(Mobile No should start from 6,7,8,9 and should be length of 10)");
			mobileNo = sc.nextLine();
		}
		try {
			System.out.println("__________________________________________________________________________________");
			System.out.println("You current balance : " + accountService.getAccountDetails(mobileNo).getAccountBalance());
			System.out.println("__________________________________________________________________________________");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	/*
	 * This method will return the upadted amount.
	 */
	private static void rechargeAccount() {
		System.out.println("__________________________________________________________________________________");
		System.out.println("Enter mobile number");
		sc.nextLine();
		String mobileNo = sc.nextLine();
		/*
		 * validation on mobile number.
		 */
		while(!validateMobileNo(mobileNo)) {
			System.out.println("Invalid Mobile number :: Try Again!!(Mobile No should start from 6,7,8,9 and should be length of 10)");
			mobileNo = sc.nextLine();
		}
		System.out.println("Enter Amount to be transferred");
		double balance = sc.nextDouble();
		/*
		 * validation on balanace.
		 */
		while(!validateAmount(balance)) {
			System.out.println("Balance should be positive and greater than 0 :: Try Again!!");
			balance = sc.nextDouble();
		}
		
		try {
			if (accountService.rechargeAccount(mobileNo, balance) == 1) {
				System.out.println("__________________________________________________________________________________");
				System.out.println("Your account sucessfully recharged");
				Account account = accountService.getAccountDetails(mobileNo);
				System.out.println("Hello " + account.getCustomerName() + " Avilable Balance is : " + account.getAccountBalance());
				System.out.println("__________________________________________________________________________________");
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	/*
	 * validation of mobile number.
	 * mobile number should be start from 6,7,8,9 and 
	 * a length of 10 digit.
	 */
	private static boolean validateMobileNo(String mobileNo) {
		Pattern pattern = Pattern.compile("[6789]{1}[0-9]{9}");
		Matcher match = pattern.matcher(mobileNo);
		if(match.matches())
			return true;
		else
			return false;
	}
	/*
	 * This Method will validate amount.
	 * amount should be greater than 0.
	 */
	private static boolean validateAmount(double amount) {
		if(amount <= 0) {
			return false;
		}
		else
			return true;
	}

}
