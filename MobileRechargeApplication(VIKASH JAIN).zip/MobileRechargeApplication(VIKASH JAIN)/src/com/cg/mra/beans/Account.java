package com.cg.mra.beans;

public class Account {
	/*
	 * data members
	 */
	private String accountType;
	private String customerName;
	private double accountBalance;
	/*
	 * Constructor with Arguments.
	 */
	public Account(String accountType, String customerName, double accountBalance) {
		super(); //Super class Constructor.
		this.accountType = accountType;
		this.customerName = customerName;
		this.accountBalance = accountBalance;
	}
	/*
	 * getters and setters.
	 */
	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public double getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}

	/*
	 * (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Account [accountType=" + accountType + ", customerName=" + customerName + ", accountBalance="
				+ accountBalance + "]";
	}
}
