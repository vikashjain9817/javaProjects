package SeleniumBDDExample.selenium;



import static org.junit.Assert.assertEquals;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;



public class SeleniumSteps {

	private static WebDriver driver = App.getDriver();
	
	@Given("^type url (.*)/$")
	public void getInformation(String url) throws Throwable {
		
		System.out.println("Open chrome browser nad search for selenium tutorial");
	}
	
	@When("^search on (.*) input for (.*) (.*) and click search and open javatpoint$")
	public void infoIsRight(String url, String name1, String name2) throws Throwable {
		driver.manage().deleteAllCookies();
		driver.manage().window().maximize();
		driver.get(url);
		Thread.sleep(2000);
		
		WebElement search =driver.findElement(By.xpath("//*[@id=\"tsf\"]/div[2]/div/div[1]/div/div[1]/input"));
		search.sendKeys("selenium tutorial");
		
		WebElement button = driver.findElement(By.xpath("//*[@id=\"tsf\"]/div[2]/div/div[3]/center/input[1]"));
		button.click();
		
		WebElement javatpoint = driver.findElement(By.xpath("//*[@id=\"rso\"]/div[3]/div/div[2]/div/div/div[1]/a"));
		javatpoint.click();
	}
	
	@Then("^(.*) website open successfully$")
	public void certifiedYes(String url) throws Throwable {
		assertEquals(url, driver.getCurrentUrl());
	}
	
}
